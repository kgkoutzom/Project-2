from sympy import symbols, groebner,  factor
from sympy import simplify  

t=symbols('t')
x=symbols('x')
y=symbols('y')
z=symbols('z')
    
p = 5*x*y - 5*y**2 - 7*x + 7*y
q = 2*x**2 - x*y - y**2
k = x**4 + 3*x**3*z + x*y**3 + 3*y**3*z
l = x**3*y - 2*x**3*z + y**4 - 2*y**3*z
m = 3*x**8 + 5*x**4*y**4 - 3*x**4*z**4 - 5*y**4*z**4
n = 7*x**8 -2*x**4*y**4 -7*x**4*z**4 + 2*y**4*z**4

def ex_5(f,g) :
    G = groebner([t*f,(1-t)*g], t, x, y, order = 'lex')

    for poly in G:
        print(poly.factor())
    print('\n')

    lcm = factor(G[2])
    gcd = simplify((p*q)/lcm)
    print('gcd: ', gcd)


print('a question :')
print ('\n')
ex_5(p,q)
print ('\n')
print('c question :')
ex_5(k,l)
print ('\n')
print('e question :')
ex_5(m,n)