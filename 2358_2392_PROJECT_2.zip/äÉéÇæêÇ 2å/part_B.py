from sympy import symbols, pprint, groebner, gcd, lcm, LM, expand, factor, reduced, Poly, ZZ, LC, LT, N, quo, gcd, simplify
from sympy.polys.subresultants_qq_zz import *

x=symbols('x')
y=symbols('y')
z=symbols('z')

p= x*y**2 + 1
g1= x*y + 1
g2= y + 1

def genpolydivision(polynomial,plist,order):
    remainder = 0
    quotients = []
    for i in range(len(plist)):
        quotients.append(0)
    newpoly = polynomial
    while simplify(newpoly)!=0:
        divoccur = 0
        for i in range(len(plist)):
            if (rem(LT(newpoly, [x, y], order=order), LT(plist[i], [x,y], order=order)) == 0):
                quotients[i]=quotients[i]+(LT(newpoly, [x,y], order=order)/LT(plist[i], [x, y], order=order))
                newpoly = newpoly - ((LT(newpoly, [x,y], order=order)/LT(plist[i], [x, y], order=order))*plist[i])
                divoccur = 1
                
                break;
        if divoccur == 0:
            remainder = remainder + LT(newpoly, [x,y], order=order)
            newpoly = newpoly - LT(newpoly, [x,y], order=order)
            
    return(remainder, quotients)

# we run an example.
result=genpolydivision(p, [g1,g2], 'lex')
print(result)
