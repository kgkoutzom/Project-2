from sympy import symbols, LT, simplify
from math import * 
 

x=symbols('x')
y=symbols('y')
 
f= x*y**2 + 1
g1= x*y + 1
g2= y + 1

f_c = x**3 + 2*x**2*y -5*x +y**3 -3*y
g1_c = x*y -1
g2_c = x**2 + y**2 -4

print('example a with [g1, g2]')
#example a with [g1, g2]

q1 = LT(f) / LT(g1)
f1 = f - g1 * q1
q2 = LT(f1) / LT(g2)
r = f1 - g2 * q2

h = g1 * q1 + g2 * q2 + r
print(h)
print('\n')

#example a with [g2, g1]
print('example a with [g2, g1]')
q2 = LT(f) / LT(g2)
f1 = simplify(f - g2 * q2)
q2_new = LT(f1) / LT(g2)
r = f1 - g2 * q2_new
q2_full = simplify(q2 + q2_new)

h = simplify(g2 * q2_full + r)


print (h)
print('\n')

#example c
print('example c with [g1, g2]')

q = LT(f_c) / LT(g2_c) # ==x
f_cc = simplify(f_c - g2_c * q) # == 2x^2 - xy^2 -x +y^3 -3y
qq = LT(f_cc) / LT(g1_c) # ==2x
f_ccc = simplify(f_cc - g1_c * qq)
qqq = LT(f_ccc) / LT(g1_c) # == -y
q1_c = qq + qqq
q2_c = q
r = simplify(f_ccc - g1_c * qqq)

h = simplify(g1_c * q1_c + g2_c * q2_c + r)

print(h)
print('\n')

print('example c with [g2, g1]')

q = LT(f_c) / LT(g2_c) # ==x
f_cc = simplify(f_c - g2_c * q)
qq = LT(f_cc) / LT(g2_c)
f_ccc = simplify(f_cc - g2_c * qq)
qqq = LT(f_ccc) / LT(g1_c)
r = simplify(f_ccc - g1_c * qqq)

q2 = q + qq
q1 = qqq

h = simplify(g2_c * q2_c + g1_c * q1_c + r)
print(h)




