from sympy import symbols, reduced
from sympy import simplify
from math import *

x=symbols('x')
y=symbols('y')
z=symbols('z')

fa = x*y - y
g1 = x*z -z
g2 = y -z
g3 = 2*z**2 -z
GA = [g1, g2, g3]

def _ex22(f, G):
    r = reduced(f, G, x, y, z)
    print("after reduced: ", r)
    if (r[1] == 0):
        print(f ,' can be expressed as a linear combination of Groebner basis elements')
        print('f =', simplify(r[0][0] * G[0] + r[0][1] * G[1] + r[0][2] * G[2]))
        return
    print(f ,' can not be expressed as a linear combination of Groebner basis elements')

    
#for example a
print('example a')        
_ex22(fa, GA)
print('\n')

#for example c
print('example c')
fc = 2*y**2 - y
_ex22(fc, GA)
print('\n')

#for example e
print('example e')
fe = 4*y**3 - z
_ex22(fe, GA)
print('\n')

#for example g
print('example g')
fg = 4*x**2*y**2*z - z
_ex22(fg, GA)
print('\n')

#for example i
print('example i')
fi = x*z - 2*y +6*z**2 -2*z
_ex22(fi, GA)
print('\n')




