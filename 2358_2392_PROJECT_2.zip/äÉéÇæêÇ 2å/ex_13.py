from sympy import ZZ
from math import *

def _ex13a(num):
    rem64=ZZ.rem(num, 64)
    quo64=ZZ.quo(num, 64)
    
    rem32=ZZ.rem(rem64,32)
    quo32=ZZ.quo(rem64,32)
    
    rem16=ZZ.rem(rem32, 16)
    quo16=ZZ.quo(rem32, 16)
    
    rem8=ZZ.rem(rem16,8)
    quo8=ZZ.quo(rem16,8)
    
    rem4=ZZ.rem(rem8, 4)
    quo4=ZZ.quo(rem8, 4)
    
    rem2=ZZ.rem(rem4, 2)
    quo2=ZZ.quo(rem4, 2)
    
    rem1=ZZ.rem(rem2, 1)
    quo1=ZZ.quo(rem2, 1)
    
    num_coins= quo64 + quo32 + quo16 + quo8 + quo4 + quo2 + quo1
    print(' The minimum number of coins necessary to purchase item costing' , num,  'is: ' , num_coins)
    print('\n')
    print('The combination of the coins is:', quo64, '*64,', quo32, '*32,', quo16, '*16,', quo8, '*8,', quo4, '*4,', quo2, '*2,', quo1, '*1.')
    print('\n')
    
print('Example a \n')
_ex13a(100)
_ex13a(117)
_ex13a(199)

def _ex13b(num):
    new_num = num * 256
    
    rem256=ZZ.rem(new_num, 256)
    quo256=ZZ.quo(new_num, 256)
    
    rem64=ZZ.rem(rem256, 64)
    quo64=ZZ.quo(rem256, 64)
    
    rem32=ZZ.rem(rem64,32)
    quo32=ZZ.quo(rem64,32)
    
    rem16=ZZ.rem(rem32, 16)
    quo16=ZZ.quo(rem32, 16)
    
    rem8=ZZ.rem(rem16,8)
    quo8=ZZ.quo(rem16,8)
    
    rem4=ZZ.rem(rem8, 4)
    quo4=ZZ.quo(rem8, 4)
    
    rem2=ZZ.rem(rem4, 2)
    quo2=ZZ.quo(rem4, 2)
    
    rem1=ZZ.rem(rem2, 1)
    quo1=ZZ.quo(rem2, 1)
    
    num_coins= quo256 + quo64 + quo32 + quo16 + quo8 + quo4 + quo2 + quo1
    print(' The minimum number of coins necessary to purchase item costing' , num,  'is: ' , num_coins)
    print('\n')
    print('The combination of the coins is:',quo256, '* 1byte,', quo64, '*64 bits,', quo32, '*32 bits,', quo16, '*16 bits,', quo8, '*8 bits,', quo4, '*4 bits,', quo2, '*2 bits,', quo1, '*1 bits.')
    print('\n')

print('Example b \n')
_ex13b(1.75)
_ex13b(2.375)
_ex13b(2.546875)