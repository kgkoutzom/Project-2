#Ομάδα 5
#Γεωργαντάς Δαυίδ 2358
#Γκουτζομήτρου Κλειώ 2392


from sympy import symbols,  groebner, solve


x=symbols('x')
y=symbols('y')
z=symbols('z')
a=symbols('a')

f = x + 2*y - 3*z - 4
g = 3*x - y + 5*z - 2
h = 4*x + y  + (a**2 -14)*z - a - 2

gr_basis= groebner([f,g,h], x,y,z)
for poly in gr_basis :
    print(poly, '= 0')
    
sols=solve(gr_basis, x,y,z)
print(sols)

#από εδώ, μπορύμε να δούμε ότι για α=4 έχουμε μοναδική λύση.
#για α=-4 το σύστημα αυτών των εξισώσεων/πολυωνύμων είναι αδύνατο, δηλαδή δεν υπάρχει καμία λύση.
#για α Ε R - {-4} - {4} το σύστημα είναι αόριστο, δηλαδή έχουμε άπειρες λύσεις.